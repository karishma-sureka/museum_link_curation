# LinkCurationApi.Login

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user** | [**[UserProfile]**](UserProfile.md) |  | [optional] 
**token** | [**[Token]**](Token.md) |  | [optional] 


