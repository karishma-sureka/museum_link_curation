# LinkCurationApi.User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **String** | Unique url endpoint for a user | [optional] 
**username** | **String** | Username that was registered | [optional] 


