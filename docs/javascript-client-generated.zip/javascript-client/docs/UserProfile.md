# LinkCurationApi.UserProfile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of the user | [optional] 
**rating** | **Integer** | User rating from 0-5. | [optional] 
**tags** | **String** | array of tag strings associated with the user | [optional] 
**username** | **String** | Username of the user | [optional] 


