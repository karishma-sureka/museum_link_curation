# LinkCurationApi.QuestionApi

All URIs are relative to *https://localhost:5000/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**questionGet**](QuestionApi.md#questionGet) | **GET** /question | Serve relevant questions from database
[**questionPost**](QuestionApi.md#questionPost) | **POST** /question | Create new question(s) (pair(s)) in the database


<a name="questionGet"></a>
# **questionGet**
> [Questions] questionGet(opts)

Serve relevant questions from database

This Question endpoint returns set of questions to client based on different paraneters associated \nwith the user and user&#39;s previous history. User Authentication required to access this API\n\nExamples: \n- curl -X GET http://localhost:5000/question -u nilayvac@usc.edu:linkCuration\n- curl -X GET http://localhost:5000/question -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;stats\&quot;:\&quot;True\&quot;}&#39; -u nilayvac@usc.edu:linkCuration\n- curl -X GET http://localhost:5000/question -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;bulk\&quot;:10}&#39; -u nilayvac@usc.edu:linkCuration\n- curl -X GET http://localhost:5000/question -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;bulk\&quot;:10,\&quot;stats\&quot;:\&quot;True\&quot;}&#39; -u nilayvac@usc.edu:linkCuration\n- curl -X GET http://localhost:5000/question -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;bulk\&quot;:10,\&quot;stats\&quot;:\&quot;True\&quot;}&#39; -u eyJhbGciOiJIUzI1NiIsImV4cCI6MTQ2MDU5OTUxNCwiaWF0IjoxNDYwNTk1OTE0fQ.eyJpZCI6Mn0.FSoeJkqaV1Zlc1XjDu5fcI3fmRSHD1OMhm-M8sKOHE8:x\n

### Example
```javascript
var LinkCurationApi = require('link-curation-api');

var apiInstance = new LinkCurationApi.QuestionApi()

var opts = { 
  'stats': true, // {Boolean} Flag to request question stastics in the response
  'bulk': 56 // {Integer} Limit number of questions returned. Default is 10
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
api.questionGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **stats** | **Boolean**| Flag to request question stastics in the response | [optional] 
 **bulk** | **Integer**| Limit number of questions returned. Default is 10 | [optional] 

### Return type

[**[Questions]**](Questions.md)

### Authorization

No authorization required

### HTTP reuqest headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="questionPost"></a>
# **questionPost**
> [Decision] questionPost(uri1, uri2, dedupe, payload, opts)

Create new question(s) (pair(s)) in the database

This Question endpoint allows external software entity like dedupe to create new questions. No authentication required. \n\nExamples:\n- curl -X POST http://localhost:5000/question -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;uri1\&quot;:\&quot;http://vocab.getty.edu/ulan/50001234\&quot;,\&quot;uri2\&quot;:\&quot;http://edan.si.edu/saam/id/person-institution/1234\&quot;,\&quot;dedupe\&quot;:{\&quot;ver\&quot;:\&quot;1.0\&quot;,\&quot;revision\&quot;:\&quot;4\&quot;,\&quot;score\&quot;:\&quot;0.45\&quot;}}&#39;\n- curl -X POST http://localhost:5000/question -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;bulk\&quot;:count n,\&quot;payload\&quot;:[{},{},... n entries]}&#39;\n- curl -X POST http://localhost:5000/question -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;bulk\&quot;:2,\&quot;payload\&quot;:[{\&quot;uri1\&quot;:\&quot;http://vocab.getty.edu/ulan/50002345\&quot;,\&quot;uri2\&quot;:\&quot;http://edan.si.edu/saam/id/person-institution/2345\&quot;,\&quot;dedupe\&quot;:{\&quot;ver\&quot;:\&quot;1.0\&quot;,\&quot;revision\&quot;:\&quot;4\&quot;,\&quot;score\&quot;:\&quot;0.45\&quot;}},{\&quot;uri1\&quot;:\&quot;http://vocab.getty.edu/ulan/50003456\&quot;,\&quot;uri2\&quot;:\&quot;http://edan.si.edu/saam/id/person-institution/3456\&quot;,\&quot;dedupe\&quot;:{\&quot;ver\&quot;:\&quot;1.0\&quot;,\&quot;revision\&quot;:\&quot;4\&quot;,\&quot;score\&quot;:\&quot;0.85\&quot;}}]}&#39;\n

### Example
```javascript
var LinkCurationApi = require('link-curation-api');

var apiInstance = new LinkCurationApi.QuestionApi()

var uri1 = "uri1_example"; // {String} One of the URI of a pair of question

var uri2 = "uri2_example"; // {String} One of the URI of a pair of question

var dedupe = "B"; // {String} Information related to pair generated from dedupe

var payload = "B"; // {String} List of three tuple, uri1, uri2 and dedupe for bulk call.

var opts = { 
  'bulk': 56 // {Integer} Set this valur for creating multiple pairs in one call
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
api.questionPost(uri1, uri2, dedupe, payload, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri1** | **String**| One of the URI of a pair of question | 
 **uri2** | **String**| One of the URI of a pair of question | 
 **dedupe** | **String**| Information related to pair generated from dedupe | 
 **payload** | **String**| List of three tuple, uri1, uri2 and dedupe for bulk call. | 
 **bulk** | **Integer**| Set this valur for creating multiple pairs in one call | [optional] 

### Return type

[**[Decision]**](Decision.md)

### Authorization

No authorization required

### HTTP reuqest headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

