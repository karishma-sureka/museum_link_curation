# LinkCurationApi.Exactmatched

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of the property that matched exactly | [optional] 
**value** | **String** | Value of the property that matched exactly on both side. | [optional] 


