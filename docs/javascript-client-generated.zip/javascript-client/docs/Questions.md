# LinkCurationApi.Questions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exactMatch** | [**[Exactmatched]**](Exactmatched.md) |  | [optional] 
**unmatched** | [**[Unmatched]**](Unmatched.md) |  | [optional] 
**qid** | **String** | Unique question ID | [optional] 
**stats** | **String** | Returns question statitics if requested in query | [optional] 


