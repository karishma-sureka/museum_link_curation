# LinkCurationApi.AnswerApi

All URIs are relative to *https://localhost:5000/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**answerPut**](AnswerApi.md#answerPut) | **PUT** /answer | Submit an answer


<a name="answerPut"></a>
# **answerPut**
> &#39;String&#39; answerPut(qid, value, opts)

Submit an answer

Submit human curated answer related to a question. User Authentication required to access this API.\n\nExamples:\n- curl -X PUT http://localhost:5000/v1/answer -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;value\&quot;:\&quot;1\&quot;,\&quot;comment\&quot;:\&quot;Just another comment\&quot;,\&quot;qid\&quot;:\&quot;570eeba7f6bf2d1e58a88471\&quot;}&#39; -u eyJhbGciOiJIUzI1NiIsImV4cCI6MTQ2MDU5OTQ4MSwiaWF0IjoxNDYwNTk1ODgxfQ.eyJpZCI6MX0.PyLZSP7q0iWh-n1yazz8p23kO3cUJtmQbGucjvTYtOg:x\n- curl -X PUT http://localhost:5000/v1/answer -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;value\&quot;:\&quot;1\&quot;,\&quot;comment\&quot;:\&quot;Just another comment\&quot;,\&quot;qid\&quot;:\&quot;570eeba7f6bf2d1e58a88471\&quot;}&#39; -u eyJhbGciOiJIUzI1NiIsImV4cCI6MTQ2MDU5OTUxNCwiaWF0IjoxNDYwNTk1OTE0fQ.eyJpZCI6Mn0.FSoeJkqaV1Zlc1XjDu5fcI3fmRSHD1OMhm-M8sKOHE8:x\n- curl -X PUT http://localhost:5000/v1/answer -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;value\&quot;:\&quot;1\&quot;,\&quot;comment\&quot;:\&quot;Just another comment\&quot;,\&quot;qid\&quot;:\&quot;570eec1df6bf2d1e58a88479\&quot;}&#39; -u nilayvac@usc.edu:linkCuration\n- curl -X PUT http://localhost:5000/v1/answer -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;value\&quot;:\&quot;1\&quot;,\&quot;comment\&quot;:\&quot;Just another comment\&quot;,\&quot;qid\&quot;:\&quot;570eec1df6bf2d1e58a88479\&quot;}&#39; -u ksureka@usc.edu:linkCuration\n

### Example
```javascript
var LinkCurationApi = require('link-curation-api');

var apiInstance = new LinkCurationApi.AnswerApi()

var qid = "qid_example"; // {String} qid of a question being answered

var value = "value_example"; // {String} Decision value from 1 to 3

var opts = { 
  'comment': "comment_example" // {String} Comment related to decision
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
api.answerPut(qid, value, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **qid** | **String**| qid of a question being answered | 
 **value** | **String**| Decision value from 1 to 3 | 
 **comment** | **String**| Comment related to decision | [optional] 

### Return type

**&#39;String&#39;**

### Authorization

No authorization required

### HTTP reuqest headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

