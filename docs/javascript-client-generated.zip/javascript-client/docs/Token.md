# LinkCurationApi.Token

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**duration** | **Integer** | Token validity in seconds | [optional] 
**value** | **String** | Alphanumeric value of a token | [optional] 


