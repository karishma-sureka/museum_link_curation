# LinkCurationApi.Decision

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Integer** | List of decision values from curation interface. 1 - Match, 2 - No Match, 3 - Not Sure | [optional] 
**comment** | **String** | List of decision comment from curation interface. | [optional] 
**message** | **String** | Message indicating that human curated information is not available. | [optional] 


