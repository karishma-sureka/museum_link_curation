# LinkCurationApi.AccountApi

All URIs are relative to *https://localhost:5000/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**userGet**](AccountApi.md#userGet) | **GET** /user | Login existing user and get time bound API token
[**userPost**](AccountApi.md#userPost) | **POST** /user | Register a new user
[**userPut**](AccountApi.md#userPut) | **PUT** /user | Update user profile


<a name="userGet"></a>
# **userGet**
> [Login] userGet(opts)

Login existing user and get time bound API token

Authenticates user credentials and returns time sensitive API access token. This token can be used instead of credentials to access protected resources\n\nExamples:\n- curl -X GET http://localhost:5000/user -H -u nilayvac@usc.edu:linkCuration\n- curl -X GET http://localhost:5000/user -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;duration\&quot;:3600}&#39; -u nilayvac@usc.edu:linkCuration\n- curl -X GET http://localhost:5000/user -u ksureka@usc.edu:linkCuration\n- curl -X GET http://localhost:5000/user -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;duration\&quot;:3600}&#39; -u ksureka@usc.edu:linkCuration\n

### Example
```javascript
var LinkCurationApi = require('link-curation-api');

var apiInstance = new LinkCurationApi.AccountApi()

var opts = { 
  'duration': 56 // {Integer} Access token validation in seconds. Default is 10 minutes
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
api.userGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **Integer**| Access token validation in seconds. Default is 10 minutes | [optional] 

### Return type

[**[Login]**](Login.md)

### Authorization

No authorization required

### HTTP reuqest headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="userPost"></a>
# **userPost**
> [User] userPost(username, password)

Register a new user

Create new user account for a curator\n\nExamples:\n- curl -X POST http://localhost:5000/user -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;username\&quot;:\&quot;nilayvac@usc.edu\&quot;,\&quot;password\&quot;:\&quot;linkCuration\&quot;}&#39;\n- curl -X POST http://localhost:5000/user -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;username\&quot;:\&quot;ksureka@usc.edu\&quot;,\&quot;password\&quot;:\&quot;linkCuration\&quot;}&#39;\n

### Example
```javascript
var LinkCurationApi = require('link-curation-api');

var apiInstance = new LinkCurationApi.AccountApi()

var username = "username_example"; // {String} Username of a user

var password = "password_example"; // {String} Password of a user


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
api.userPost(username, password, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **String**| Username of a user | 
 **password** | **String**| Password of a user | 

### Return type

[**[User]**](User.md)

### Authorization

No authorization required

### HTTP reuqest headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="userPut"></a>
# **userPut**
> [Login] userPut(opts)

Update user profile

Update user profile details like name of the user, tags and rating. User Authentication required to access this API. At least one of the three paraneters is required\n\nExampls:\n- curl -X PUT http://localhost:5000/user -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;name\&quot;:\&quot;Nilay Chheda\&quot;,\&quot;rating\&quot;:5,\&quot;tags\&quot;:[\&quot;saam\&quot;,\&quot;ulan\&quot;]}&#39; -u nilayvac@usc.edu:linkCuration\n- curl -X PUT http://localhost:5000/user -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;name\&quot;:\&quot;Nilay Chheda\&quot;,\&quot;rating\&quot;:5,\&quot;tags\&quot;:[\&quot;saam\&quot;,\&quot;ulan\&quot;]}&#39; -u eyJhbGciOiJIUzI1NiIsImV4cCI6MTQ2MDU5OTUxNCwiaWF0IjoxNDYwNTk1OTE0fQ.eyJpZCI6Mn0.FSoeJkqaV1Zlc1XjDu5fcI3fmRSHD1OMhm-M8sKOHE8:x\n- curl -X PUT http://localhost:5000/user -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;name\&quot;:\&quot;Karishma Sureka\&quot;,\&quot;rating\&quot;:5,\&quot;tags\&quot;:[\&quot;dbpedia\&quot;,\&quot;npg\&quot;]}&#39; -u ksureka@usc.edu:linkCuration\n- curl -X PUT http://localhost:5000/user -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;name\&quot;:\&quot;Karishma Sureka\&quot;,\&quot;rating\&quot;:5,\&quot;tags\&quot;:[\&quot;dbpedia\&quot;,\&quot;npg\&quot;]}&#39; -u eyJhbGciOiJIUzI1NiIsImV4cCI6MTQ2MDU5OTUxNCwiaWF0IjoxNDYwNTk1OTE0fQ.eyJpZCI6Mn0.FSoeJkqaV1Zlc1XjDu5fcI3fmRSHD1OMhm-M8sKOHE8:x\n

### Example
```javascript
var LinkCurationApi = require('link-curation-api');

var apiInstance = new LinkCurationApi.AccountApi()

var opts = { 
  'name': "name_example", // {String} Name of the user
  'rating': 56, // {Integer} Rating of the user
  'tags': "tags_example" // {String} Tags of the user in String array
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
api.userPut(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **String**| Name of the user | [optional] 
 **rating** | **Integer**| Rating of the user | [optional] 
 **tags** | **String**| Tags of the user in String array | [optional] 

### Return type

[**[Login]**](Login.md)

### Authorization

No authorization required

### HTTP reuqest headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

