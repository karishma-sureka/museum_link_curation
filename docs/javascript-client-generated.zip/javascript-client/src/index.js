(function(factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['./ApiClient', './model/Decision', './model/Error', './model/Exactmatched', './model/Login', './model/Questions', './model/Token', './model/Unmatched', './model/User', './model/UserProfile', './api/AccountApi', './api/AnswerApi', './api/QuestionApi'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('./ApiClient'), require('./model/Decision'), require('./model/Error'), require('./model/Exactmatched'), require('./model/Login'), require('./model/Questions'), require('./model/Token'), require('./model/Unmatched'), require('./model/User'), require('./model/UserProfile'), require('./api/AccountApi'), require('./api/AnswerApi'), require('./api/QuestionApi'));
  }
}(function(ApiClient, Decision, Error, Exactmatched, Login, Questions, Token, Unmatched, User, UserProfile, AccountApi, AnswerApi, QuestionApi) {
  'use strict';

  /**
   * We support three basic APIs- Questions, Answers and Account Services.<br>
   * The <code>index</code> module provides access to constructors for all the classes which comprise the public API.
   * <p>
   * An AMD (recommended!) or CommonJS application will generally do something equivalent to the following:
   * <pre>
   * var LinkCurationApi = require('./index'); // See note below*.
   * var xxxSvc = new LinkCurationApi.XxxApi(); // Allocate the API class we're going to use.
   * var yyyModel = new LinkCurationApi.Yyy(); // Construct a model instance.
   * yyyModel.someProperty = 'someValue';
   * ...
   * var zzz = xxxSvc.doSomething(yyyModel); // Invoke the service.
   * ...
   * </pre>
   * <em>*NOTE: For a top-level AMD script, use require(['./index'], function(){...}) and put the application logic within the
   * callback function.</em>
   * </p>
   * <p>
   * A non-AMD browser application (discouraged) might do something like this:
   * <pre>
   * var xxxSvc = new LinkCurationApi.XxxApi(); // Allocate the API class we're going to use.
   * var yyy = new LinkCurationApi.Yyy(); // Construct a model instance.
   * yyyModel.someProperty = 'someValue';
   * ...
   * var zzz = xxxSvc.doSomething(yyyModel); // Invoke the service.
   * ...
   * </pre>
   * </p>
   * @module index
   * @version 1.0.0
   */
  var exports = {
    /**
     * The ApiClient constructor.
     * @property {module:ApiClient}
     */
    ApiClient: ApiClient,
    /**
     * The Decision model constructor.
     * @property {module:model/Decision}
     */
    Decision: Decision,
    /**
     * The Error model constructor.
     * @property {module:model/Error}
     */
    Error: Error,
    /**
     * The Exactmatched model constructor.
     * @property {module:model/Exactmatched}
     */
    Exactmatched: Exactmatched,
    /**
     * The Login model constructor.
     * @property {module:model/Login}
     */
    Login: Login,
    /**
     * The Questions model constructor.
     * @property {module:model/Questions}
     */
    Questions: Questions,
    /**
     * The Token model constructor.
     * @property {module:model/Token}
     */
    Token: Token,
    /**
     * The Unmatched model constructor.
     * @property {module:model/Unmatched}
     */
    Unmatched: Unmatched,
    /**
     * The User model constructor.
     * @property {module:model/User}
     */
    User: User,
    /**
     * The UserProfile model constructor.
     * @property {module:model/UserProfile}
     */
    UserProfile: UserProfile,
    /**
     * The AccountApi service constructor.
     * @property {module:api/AccountApi}
     */
    AccountApi: AccountApi,
    /**
     * The AnswerApi service constructor.
     * @property {module:api/AnswerApi}
     */
    AnswerApi: AnswerApi,
    /**
     * The QuestionApi service constructor.
     * @property {module:api/QuestionApi}
     */
    QuestionApi: QuestionApi
  };

  return exports;
}));
