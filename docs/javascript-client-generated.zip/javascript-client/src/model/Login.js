(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient', './Token', './UserProfile'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'), require('./Token'), require('./UserProfile'));
  } else {
    // Browser globals (root is window)
    if (!root.LinkCurationApi) {
      root.LinkCurationApi = {};
    }
    root.LinkCurationApi.Login = factory(root.LinkCurationApi.ApiClient, root.LinkCurationApi.Token, root.LinkCurationApi.UserProfile);
  }
}(this, function(ApiClient, Token, UserProfile) {
  'use strict';

  /**
   * The Login model module.
   * @module model/Login
   * @version 1.0.0
   */

  /**
   * Constructs a new <code>Login</code>.
   * @alias module:model/Login
   * @class
   */
  var exports = function() {



  };

  /**
   * Constructs a <code>Login</code> from a plain JavaScript object, optionally creating a new instance.
   * Copies all relevant properties from <code>data</code> to <code>obj</code> if supplied or a new instance if not.
   * @param {Object} data The plain JavaScript object bearing properties of interest.
   * @param {module:model/Login} obj Optional instance to populate.
   * @return {module:model/Login} The populated <code>Login</code> instance.
   */
  exports.constructFromObject = function(data, obj) {
    if (data) { 
      obj = obj || new exports();

      if (data.hasOwnProperty('User')) {
        obj['User'] = ApiClient.convertToType(data['User'], [UserProfile]);
      }
      if (data.hasOwnProperty('Token')) {
        obj['Token'] = ApiClient.convertToType(data['Token'], [Token]);
      }
    }
    return obj;
  }


  /**
   * @member {Array.<module:model/UserProfile>} User
   */
  exports.prototype['User'] = undefined;

  /**
   * @member {Array.<module:model/Token>} Token
   */
  exports.prototype['Token'] = undefined;




  return exports;
}));
