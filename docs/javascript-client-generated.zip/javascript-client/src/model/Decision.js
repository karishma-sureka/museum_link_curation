(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'));
  } else {
    // Browser globals (root is window)
    if (!root.LinkCurationApi) {
      root.LinkCurationApi = {};
    }
    root.LinkCurationApi.Decision = factory(root.LinkCurationApi.ApiClient);
  }
}(this, function(ApiClient) {
  'use strict';

  /**
   * The Decision model module.
   * @module model/Decision
   * @version 1.0.0
   */

  /**
   * Constructs a new <code>Decision</code>.
   * @alias module:model/Decision
   * @class
   */
  var exports = function() {




  };

  /**
   * Constructs a <code>Decision</code> from a plain JavaScript object, optionally creating a new instance.
   * Copies all relevant properties from <code>data</code> to <code>obj</code> if supplied or a new instance if not.
   * @param {Object} data The plain JavaScript object bearing properties of interest.
   * @param {module:model/Decision} obj Optional instance to populate.
   * @return {module:model/Decision} The populated <code>Decision</code> instance.
   */
  exports.constructFromObject = function(data, obj) {
    if (data) { 
      obj = obj || new exports();

      if (data.hasOwnProperty('Value')) {
        obj['Value'] = ApiClient.convertToType(data['Value'], 'Integer');
      }
      if (data.hasOwnProperty('comment')) {
        obj['comment'] = ApiClient.convertToType(data['comment'], 'String');
      }
      if (data.hasOwnProperty('message')) {
        obj['message'] = ApiClient.convertToType(data['message'], 'String');
      }
    }
    return obj;
  }


  /**
   * List of decision values from curation interface. 1 - Match, 2 - No Match, 3 - Not Sure
   * @member {Integer} Value
   */
  exports.prototype['Value'] = undefined;

  /**
   * List of decision comment from curation interface.
   * @member {String} comment
   */
  exports.prototype['comment'] = undefined;

  /**
   * Message indicating that human curated information is not available.
   * @member {String} message
   */
  exports.prototype['message'] = undefined;




  return exports;
}));
