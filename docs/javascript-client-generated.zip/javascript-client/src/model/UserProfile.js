(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'));
  } else {
    // Browser globals (root is window)
    if (!root.LinkCurationApi) {
      root.LinkCurationApi = {};
    }
    root.LinkCurationApi.UserProfile = factory(root.LinkCurationApi.ApiClient);
  }
}(this, function(ApiClient) {
  'use strict';

  /**
   * The UserProfile model module.
   * @module model/UserProfile
   * @version 1.0.0
   */

  /**
   * Constructs a new <code>UserProfile</code>.
   * @alias module:model/UserProfile
   * @class
   */
  var exports = function() {





  };

  /**
   * Constructs a <code>UserProfile</code> from a plain JavaScript object, optionally creating a new instance.
   * Copies all relevant properties from <code>data</code> to <code>obj</code> if supplied or a new instance if not.
   * @param {Object} data The plain JavaScript object bearing properties of interest.
   * @param {module:model/UserProfile} obj Optional instance to populate.
   * @return {module:model/UserProfile} The populated <code>UserProfile</code> instance.
   */
  exports.constructFromObject = function(data, obj) {
    if (data) { 
      obj = obj || new exports();

      if (data.hasOwnProperty('name')) {
        obj['name'] = ApiClient.convertToType(data['name'], 'String');
      }
      if (data.hasOwnProperty('rating')) {
        obj['rating'] = ApiClient.convertToType(data['rating'], 'Integer');
      }
      if (data.hasOwnProperty('tags')) {
        obj['tags'] = ApiClient.convertToType(data['tags'], 'String');
      }
      if (data.hasOwnProperty('username')) {
        obj['username'] = ApiClient.convertToType(data['username'], 'String');
      }
    }
    return obj;
  }


  /**
   * Name of the user
   * @member {String} name
   */
  exports.prototype['name'] = undefined;

  /**
   * User rating from 0-5.
   * @member {Integer} rating
   */
  exports.prototype['rating'] = undefined;

  /**
   * array of tag strings associated with the user
   * @member {String} tags
   */
  exports.prototype['tags'] = undefined;

  /**
   * Username of the user
   * @member {String} username
   */
  exports.prototype['username'] = undefined;




  return exports;
}));
