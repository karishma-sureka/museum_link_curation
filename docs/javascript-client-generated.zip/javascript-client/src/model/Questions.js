(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient', './Exactmatched', './Unmatched'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'), require('./Exactmatched'), require('./Unmatched'));
  } else {
    // Browser globals (root is window)
    if (!root.LinkCurationApi) {
      root.LinkCurationApi = {};
    }
    root.LinkCurationApi.Questions = factory(root.LinkCurationApi.ApiClient, root.LinkCurationApi.Exactmatched, root.LinkCurationApi.Unmatched);
  }
}(this, function(ApiClient, Exactmatched, Unmatched) {
  'use strict';

  /**
   * The Questions model module.
   * @module model/Questions
   * @version 1.0.0
   */

  /**
   * Constructs a new <code>Questions</code>.
   * @alias module:model/Questions
   * @class
   */
  var exports = function() {





  };

  /**
   * Constructs a <code>Questions</code> from a plain JavaScript object, optionally creating a new instance.
   * Copies all relevant properties from <code>data</code> to <code>obj</code> if supplied or a new instance if not.
   * @param {Object} data The plain JavaScript object bearing properties of interest.
   * @param {module:model/Questions} obj Optional instance to populate.
   * @return {module:model/Questions} The populated <code>Questions</code> instance.
   */
  exports.constructFromObject = function(data, obj) {
    if (data) { 
      obj = obj || new exports();

      if (data.hasOwnProperty('Exact_Match')) {
        obj['Exact_Match'] = ApiClient.convertToType(data['Exact_Match'], [Exactmatched]);
      }
      if (data.hasOwnProperty('Unmatched')) {
        obj['Unmatched'] = ApiClient.convertToType(data['Unmatched'], [Unmatched]);
      }
      if (data.hasOwnProperty('qid')) {
        obj['qid'] = ApiClient.convertToType(data['qid'], 'String');
      }
      if (data.hasOwnProperty('stats')) {
        obj['stats'] = ApiClient.convertToType(data['stats'], 'String');
      }
    }
    return obj;
  }


  /**
   * @member {Array.<module:model/Exactmatched>} Exact_Match
   */
  exports.prototype['Exact_Match'] = undefined;

  /**
   * @member {Array.<module:model/Unmatched>} Unmatched
   */
  exports.prototype['Unmatched'] = undefined;

  /**
   * Unique question ID
   * @member {String} qid
   */
  exports.prototype['qid'] = undefined;

  /**
   * Returns question statitics if requested in query
   * @member {String} stats
   */
  exports.prototype['stats'] = undefined;




  return exports;
}));
