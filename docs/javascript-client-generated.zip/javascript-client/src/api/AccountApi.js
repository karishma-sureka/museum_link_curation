(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient', '../model/Error', '../model/Login', '../model/User'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'), require('../model/Error'), require('../model/Login'), require('../model/User'));
  } else {
    // Browser globals (root is window)
    if (!root.LinkCurationApi) {
      root.LinkCurationApi = {};
    }
    root.LinkCurationApi.AccountApi = factory(root.LinkCurationApi.ApiClient, root.LinkCurationApi.Error, root.LinkCurationApi.Login, root.LinkCurationApi.User);
  }
}(this, function(ApiClient, Error, Login, User) {
  'use strict';

  /**
   * Account service.
   * @module api/AccountApi
   * @version 1.0.0
   */

  /**
   * Constructs a new AccountApi. 
   * @alias module:api/AccountApi
   * @class
   * @param {module:ApiClient} apiClient Optional API client implementation to use, default to {@link module:ApiClient#instance}
   * if unspecified.
   */
  var exports = function(apiClient) {
    this.apiClient = apiClient || ApiClient.instance;


    /**
     * Callback function to receive the result of the userGet operation.
     * @callback module:api/AccountApi~userGetCallback
     * @param {String} error Error message, if any.
     * @param {Array.<module:model/Login>} data The data returned by the service call.
     * @param {String} response The complete HTTP response.
     */

    /**
     * Login existing user and get time bound API token
     * Authenticates user credentials and returns time sensitive API access token. This token can be used instead of credentials to access protected resources\n\nExamples:\n- curl -X GET http://localhost:5000/user -H -u nilayvac@usc.edu:linkCuration\n- curl -X GET http://localhost:5000/user -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;duration\&quot;:3600}&#39; -u nilayvac@usc.edu:linkCuration\n- curl -X GET http://localhost:5000/user -u ksureka@usc.edu:linkCuration\n- curl -X GET http://localhost:5000/user -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;duration\&quot;:3600}&#39; -u ksureka@usc.edu:linkCuration\n
     * @param {Object} opts Optional parameters
     * @param {Integer} opts.duration Access token validation in seconds. Default is 10 minutes
     * @param {module:api/AccountApi~userGetCallback} callback The callback function, accepting three arguments: error, data, response
     * data is of type: {Array.<module:model/Login>}
     */
    this.userGet = function(opts, callback) {
      opts = opts || {};
      var postBody = null;


      var pathParams = {
      };
      var queryParams = {
        'duration': opts['duration']
      };
      var headerParams = {
      };
      var formParams = {
      };

      var authNames = [];
      var contentTypes = [];
      var accepts = ['application/json'];
      var returnType = [Login];

      return this.apiClient.callApi(
        '/user', 'GET',
        pathParams, queryParams, headerParams, formParams, postBody,
        authNames, contentTypes, accepts, returnType, callback
      );
    }

    /**
     * Callback function to receive the result of the userPost operation.
     * @callback module:api/AccountApi~userPostCallback
     * @param {String} error Error message, if any.
     * @param {Array.<module:model/User>} data The data returned by the service call.
     * @param {String} response The complete HTTP response.
     */

    /**
     * Register a new user
     * Create new user account for a curator\n\nExamples:\n- curl -X POST http://localhost:5000/user -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;username\&quot;:\&quot;nilayvac@usc.edu\&quot;,\&quot;password\&quot;:\&quot;linkCuration\&quot;}&#39;\n- curl -X POST http://localhost:5000/user -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;username\&quot;:\&quot;ksureka@usc.edu\&quot;,\&quot;password\&quot;:\&quot;linkCuration\&quot;}&#39;\n
     * @param {String} username Username of a user
     * @param {String} password Password of a user
     * @param {module:api/AccountApi~userPostCallback} callback The callback function, accepting three arguments: error, data, response
     * data is of type: {Array.<module:model/User>}
     */
    this.userPost = function(username, password, callback) {
      var postBody = null;

      // verify the required parameter 'username' is set
      if (username == undefined || username == null) {
        throw "Missing the required parameter 'username' when calling userPost";
      }

      // verify the required parameter 'password' is set
      if (password == undefined || password == null) {
        throw "Missing the required parameter 'password' when calling userPost";
      }


      var pathParams = {
      };
      var queryParams = {
        'username': username,
        'password': password
      };
      var headerParams = {
      };
      var formParams = {
      };

      var authNames = [];
      var contentTypes = [];
      var accepts = ['application/json'];
      var returnType = [User];

      return this.apiClient.callApi(
        '/user', 'POST',
        pathParams, queryParams, headerParams, formParams, postBody,
        authNames, contentTypes, accepts, returnType, callback
      );
    }

    /**
     * Callback function to receive the result of the userPut operation.
     * @callback module:api/AccountApi~userPutCallback
     * @param {String} error Error message, if any.
     * @param {Array.<module:model/Login>} data The data returned by the service call.
     * @param {String} response The complete HTTP response.
     */

    /**
     * Update user profile
     * Update user profile details like name of the user, tags and rating. User Authentication required to access this API. At least one of the three paraneters is required\n\nExampls:\n- curl -X PUT http://localhost:5000/user -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;name\&quot;:\&quot;Nilay Chheda\&quot;,\&quot;rating\&quot;:5,\&quot;tags\&quot;:[\&quot;saam\&quot;,\&quot;ulan\&quot;]}&#39; -u nilayvac@usc.edu:linkCuration\n- curl -X PUT http://localhost:5000/user -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;name\&quot;:\&quot;Nilay Chheda\&quot;,\&quot;rating\&quot;:5,\&quot;tags\&quot;:[\&quot;saam\&quot;,\&quot;ulan\&quot;]}&#39; -u eyJhbGciOiJIUzI1NiIsImV4cCI6MTQ2MDU5OTUxNCwiaWF0IjoxNDYwNTk1OTE0fQ.eyJpZCI6Mn0.FSoeJkqaV1Zlc1XjDu5fcI3fmRSHD1OMhm-M8sKOHE8:x\n- curl -X PUT http://localhost:5000/user -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;name\&quot;:\&quot;Karishma Sureka\&quot;,\&quot;rating\&quot;:5,\&quot;tags\&quot;:[\&quot;dbpedia\&quot;,\&quot;npg\&quot;]}&#39; -u ksureka@usc.edu:linkCuration\n- curl -X PUT http://localhost:5000/user -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;name\&quot;:\&quot;Karishma Sureka\&quot;,\&quot;rating\&quot;:5,\&quot;tags\&quot;:[\&quot;dbpedia\&quot;,\&quot;npg\&quot;]}&#39; -u eyJhbGciOiJIUzI1NiIsImV4cCI6MTQ2MDU5OTUxNCwiaWF0IjoxNDYwNTk1OTE0fQ.eyJpZCI6Mn0.FSoeJkqaV1Zlc1XjDu5fcI3fmRSHD1OMhm-M8sKOHE8:x\n
     * @param {Object} opts Optional parameters
     * @param {String} opts.name Name of the user
     * @param {Integer} opts.rating Rating of the user
     * @param {String} opts.tags Tags of the user in String array
     * @param {module:api/AccountApi~userPutCallback} callback The callback function, accepting three arguments: error, data, response
     * data is of type: {Array.<module:model/Login>}
     */
    this.userPut = function(opts, callback) {
      opts = opts || {};
      var postBody = null;


      var pathParams = {
      };
      var queryParams = {
        'name': opts['name'],
        'rating': opts['rating'],
        'tags': opts['tags']
      };
      var headerParams = {
      };
      var formParams = {
      };

      var authNames = [];
      var contentTypes = [];
      var accepts = ['application/json'];
      var returnType = [Login];

      return this.apiClient.callApi(
        '/user', 'PUT',
        pathParams, queryParams, headerParams, formParams, postBody,
        authNames, contentTypes, accepts, returnType, callback
      );
    }
  };

  return exports;
}));
