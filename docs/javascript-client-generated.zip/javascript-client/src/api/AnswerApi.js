(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient', '../model/Error'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'), require('../model/Error'));
  } else {
    // Browser globals (root is window)
    if (!root.LinkCurationApi) {
      root.LinkCurationApi = {};
    }
    root.LinkCurationApi.AnswerApi = factory(root.LinkCurationApi.ApiClient, root.LinkCurationApi.Error);
  }
}(this, function(ApiClient, Error) {
  'use strict';

  /**
   * Answer service.
   * @module api/AnswerApi
   * @version 1.0.0
   */

  /**
   * Constructs a new AnswerApi. 
   * @alias module:api/AnswerApi
   * @class
   * @param {module:ApiClient} apiClient Optional API client implementation to use, default to {@link module:ApiClient#instance}
   * if unspecified.
   */
  var exports = function(apiClient) {
    this.apiClient = apiClient || ApiClient.instance;


    /**
     * Callback function to receive the result of the answerPut operation.
     * @callback module:api/AnswerApi~answerPutCallback
     * @param {String} error Error message, if any.
     * @param {'String'} data The data returned by the service call.
     * @param {String} response The complete HTTP response.
     */

    /**
     * Submit an answer
     * Submit human curated answer related to a question. User Authentication required to access this API.\n\nExamples:\n- curl -X PUT http://localhost:5000/v1/answer -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;value\&quot;:\&quot;1\&quot;,\&quot;comment\&quot;:\&quot;Just another comment\&quot;,\&quot;qid\&quot;:\&quot;570eeba7f6bf2d1e58a88471\&quot;}&#39; -u eyJhbGciOiJIUzI1NiIsImV4cCI6MTQ2MDU5OTQ4MSwiaWF0IjoxNDYwNTk1ODgxfQ.eyJpZCI6MX0.PyLZSP7q0iWh-n1yazz8p23kO3cUJtmQbGucjvTYtOg:x\n- curl -X PUT http://localhost:5000/v1/answer -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;value\&quot;:\&quot;1\&quot;,\&quot;comment\&quot;:\&quot;Just another comment\&quot;,\&quot;qid\&quot;:\&quot;570eeba7f6bf2d1e58a88471\&quot;}&#39; -u eyJhbGciOiJIUzI1NiIsImV4cCI6MTQ2MDU5OTUxNCwiaWF0IjoxNDYwNTk1OTE0fQ.eyJpZCI6Mn0.FSoeJkqaV1Zlc1XjDu5fcI3fmRSHD1OMhm-M8sKOHE8:x\n- curl -X PUT http://localhost:5000/v1/answer -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;value\&quot;:\&quot;1\&quot;,\&quot;comment\&quot;:\&quot;Just another comment\&quot;,\&quot;qid\&quot;:\&quot;570eec1df6bf2d1e58a88479\&quot;}&#39; -u nilayvac@usc.edu:linkCuration\n- curl -X PUT http://localhost:5000/v1/answer -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;value\&quot;:\&quot;1\&quot;,\&quot;comment\&quot;:\&quot;Just another comment\&quot;,\&quot;qid\&quot;:\&quot;570eec1df6bf2d1e58a88479\&quot;}&#39; -u ksureka@usc.edu:linkCuration\n
     * @param {String} qid qid of a question being answered
     * @param {String} value Decision value from 1 to 3
     * @param {Object} opts Optional parameters
     * @param {String} opts.comment Comment related to decision
     * @param {module:api/AnswerApi~answerPutCallback} callback The callback function, accepting three arguments: error, data, response
     * data is of type: {'String'}
     */
    this.answerPut = function(qid, value, opts, callback) {
      opts = opts || {};
      var postBody = null;

      // verify the required parameter 'qid' is set
      if (qid == undefined || qid == null) {
        throw "Missing the required parameter 'qid' when calling answerPut";
      }

      // verify the required parameter 'value' is set
      if (value == undefined || value == null) {
        throw "Missing the required parameter 'value' when calling answerPut";
      }


      var pathParams = {
      };
      var queryParams = {
        'qid': qid,
        'comment': opts['comment'],
        'value': value
      };
      var headerParams = {
      };
      var formParams = {
      };

      var authNames = [];
      var contentTypes = [];
      var accepts = ['application/json'];
      var returnType = 'String';

      return this.apiClient.callApi(
        '/answer', 'PUT',
        pathParams, queryParams, headerParams, formParams, postBody,
        authNames, contentTypes, accepts, returnType, callback
      );
    }
  };

  return exports;
}));
