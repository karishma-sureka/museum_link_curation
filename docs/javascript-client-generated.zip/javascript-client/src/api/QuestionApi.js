(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient', '../model/Error', '../model/Questions', '../model/Decision'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'), require('../model/Error'), require('../model/Questions'), require('../model/Decision'));
  } else {
    // Browser globals (root is window)
    if (!root.LinkCurationApi) {
      root.LinkCurationApi = {};
    }
    root.LinkCurationApi.QuestionApi = factory(root.LinkCurationApi.ApiClient, root.LinkCurationApi.Error, root.LinkCurationApi.Questions, root.LinkCurationApi.Decision);
  }
}(this, function(ApiClient, Error, Questions, Decision) {
  'use strict';

  /**
   * Question service.
   * @module api/QuestionApi
   * @version 1.0.0
   */

  /**
   * Constructs a new QuestionApi. 
   * @alias module:api/QuestionApi
   * @class
   * @param {module:ApiClient} apiClient Optional API client implementation to use, default to {@link module:ApiClient#instance}
   * if unspecified.
   */
  var exports = function(apiClient) {
    this.apiClient = apiClient || ApiClient.instance;


    /**
     * Callback function to receive the result of the questionGet operation.
     * @callback module:api/QuestionApi~questionGetCallback
     * @param {String} error Error message, if any.
     * @param {Array.<module:model/Questions>} data The data returned by the service call.
     * @param {String} response The complete HTTP response.
     */

    /**
     * Serve relevant questions from database
     * This Question endpoint returns set of questions to client based on different paraneters associated \nwith the user and user&#39;s previous history. User Authentication required to access this API\n\nExamples: \n- curl -X GET http://localhost:5000/question -u nilayvac@usc.edu:linkCuration\n- curl -X GET http://localhost:5000/question -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;stats\&quot;:\&quot;True\&quot;}&#39; -u nilayvac@usc.edu:linkCuration\n- curl -X GET http://localhost:5000/question -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;bulk\&quot;:10}&#39; -u nilayvac@usc.edu:linkCuration\n- curl -X GET http://localhost:5000/question -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;bulk\&quot;:10,\&quot;stats\&quot;:\&quot;True\&quot;}&#39; -u nilayvac@usc.edu:linkCuration\n- curl -X GET http://localhost:5000/question -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;bulk\&quot;:10,\&quot;stats\&quot;:\&quot;True\&quot;}&#39; -u eyJhbGciOiJIUzI1NiIsImV4cCI6MTQ2MDU5OTUxNCwiaWF0IjoxNDYwNTk1OTE0fQ.eyJpZCI6Mn0.FSoeJkqaV1Zlc1XjDu5fcI3fmRSHD1OMhm-M8sKOHE8:x\n
     * @param {Object} opts Optional parameters
     * @param {Boolean} opts.stats Flag to request question stastics in the response
     * @param {Integer} opts.bulk Limit number of questions returned. Default is 10
     * @param {module:api/QuestionApi~questionGetCallback} callback The callback function, accepting three arguments: error, data, response
     * data is of type: {Array.<module:model/Questions>}
     */
    this.questionGet = function(opts, callback) {
      opts = opts || {};
      var postBody = null;


      var pathParams = {
      };
      var queryParams = {
        'stats': opts['stats'],
        'bulk': opts['bulk']
      };
      var headerParams = {
      };
      var formParams = {
      };

      var authNames = [];
      var contentTypes = [];
      var accepts = ['application/json'];
      var returnType = [Questions];

      return this.apiClient.callApi(
        '/question', 'GET',
        pathParams, queryParams, headerParams, formParams, postBody,
        authNames, contentTypes, accepts, returnType, callback
      );
    }

    /**
     * Callback function to receive the result of the questionPost operation.
     * @callback module:api/QuestionApi~questionPostCallback
     * @param {String} error Error message, if any.
     * @param {Array.<module:model/Decision>} data The data returned by the service call.
     * @param {String} response The complete HTTP response.
     */

    /**
     * Create new question(s) (pair(s)) in the database
     * This Question endpoint allows external software entity like dedupe to create new questions. No authentication required. \n\nExamples:\n- curl -X POST http://localhost:5000/question -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;uri1\&quot;:\&quot;http://vocab.getty.edu/ulan/50001234\&quot;,\&quot;uri2\&quot;:\&quot;http://edan.si.edu/saam/id/person-institution/1234\&quot;,\&quot;dedupe\&quot;:{\&quot;ver\&quot;:\&quot;1.0\&quot;,\&quot;revision\&quot;:\&quot;4\&quot;,\&quot;score\&quot;:\&quot;0.45\&quot;}}&#39;\n- curl -X POST http://localhost:5000/question -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;bulk\&quot;:count n,\&quot;payload\&quot;:[{},{},... n entries]}&#39;\n- curl -X POST http://localhost:5000/question -H \&quot;Content-Type: application/json\&quot; -d &#39;{\&quot;bulk\&quot;:2,\&quot;payload\&quot;:[{\&quot;uri1\&quot;:\&quot;http://vocab.getty.edu/ulan/50002345\&quot;,\&quot;uri2\&quot;:\&quot;http://edan.si.edu/saam/id/person-institution/2345\&quot;,\&quot;dedupe\&quot;:{\&quot;ver\&quot;:\&quot;1.0\&quot;,\&quot;revision\&quot;:\&quot;4\&quot;,\&quot;score\&quot;:\&quot;0.45\&quot;}},{\&quot;uri1\&quot;:\&quot;http://vocab.getty.edu/ulan/50003456\&quot;,\&quot;uri2\&quot;:\&quot;http://edan.si.edu/saam/id/person-institution/3456\&quot;,\&quot;dedupe\&quot;:{\&quot;ver\&quot;:\&quot;1.0\&quot;,\&quot;revision\&quot;:\&quot;4\&quot;,\&quot;score\&quot;:\&quot;0.85\&quot;}}]}&#39;\n
     * @param {String} uri1 One of the URI of a pair of question
     * @param {String} uri2 One of the URI of a pair of question
     * @param {String} dedupe Information related to pair generated from dedupe
     * @param {String} payload List of three tuple, uri1, uri2 and dedupe for bulk call.
     * @param {Object} opts Optional parameters
     * @param {Integer} opts.bulk Set this valur for creating multiple pairs in one call
     * @param {module:api/QuestionApi~questionPostCallback} callback The callback function, accepting three arguments: error, data, response
     * data is of type: {Array.<module:model/Decision>}
     */
    this.questionPost = function(uri1, uri2, dedupe, payload, opts, callback) {
      opts = opts || {};
      var postBody = null;

      // verify the required parameter 'uri1' is set
      if (uri1 == undefined || uri1 == null) {
        throw "Missing the required parameter 'uri1' when calling questionPost";
      }

      // verify the required parameter 'uri2' is set
      if (uri2 == undefined || uri2 == null) {
        throw "Missing the required parameter 'uri2' when calling questionPost";
      }

      // verify the required parameter 'dedupe' is set
      if (dedupe == undefined || dedupe == null) {
        throw "Missing the required parameter 'dedupe' when calling questionPost";
      }

      // verify the required parameter 'payload' is set
      if (payload == undefined || payload == null) {
        throw "Missing the required parameter 'payload' when calling questionPost";
      }


      var pathParams = {
      };
      var queryParams = {
        'uri1': uri1,
        'uri2': uri2,
        'dedupe': dedupe,
        'bulk': opts['bulk'],
        'payload': payload
      };
      var headerParams = {
      };
      var formParams = {
      };

      var authNames = [];
      var contentTypes = [];
      var accepts = ['application/json'];
      var returnType = [Decision];

      return this.apiClient.callApi(
        '/question', 'POST',
        pathParams, queryParams, headerParams, formParams, postBody,
        authNames, contentTypes, accepts, returnType, callback
      );
    }
  };

  return exports;
}));
